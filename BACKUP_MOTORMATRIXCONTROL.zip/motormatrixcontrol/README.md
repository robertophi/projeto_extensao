# Especificações de Formatação #

* Comentar os códigos quando necessário

* Comentar sempre os commits com as mudanças

* Sempre modificar códigos em branches

* Utilizar o codigo topo como padrão para formatação dos outros códigos