#ifndef __emote3_esp8266_h_

// This work is licensed under the EPOS Software License v1.0.
// A copy of this license is available at the EPOS system source tree root.
// A copy of this license is also available online at:
// http://epos.lisha.ufsc.br/EPOS+Software+License+v1.0
// Note that EPOS Software License applies to both source code and executables.
#define __emote3_esp8266_h_

#include <machine/cortex_m/emote3_gptm.h>

__BEGIN_SYS

#define ESP_LINE_END            "\r\n"
#define ESP_OK_RESPONSE         "OK"
#define ESP_SEND_OK_RESPONSE    "SEND OK"
#define ESP_LISTEN_TIMEOUT      60000 // microseconds
#define ESP_TIMEOUT             600000
#define ESP_MAX_TIMEOUT         6000000

// ESP8266 ESP-01(AT version 0.21)
class eMote3_ESP8266 {
public:
    eMote3_ESP8266(GPIO &ch_pd, GPIO &reset, UART &uart):
        ch_pd(ch_pd),
        reset(reset),
        uart(uart)
    {
        ch_pd.output();
        reset.output();
        reset.set();
        power_on();
        eMote3_GPTM::delay(ESP_MAX_TIMEOUT);
        disable_echo();
    }

    void power_on()
    {
        ch_pd.set();
    }

    void power_off()
    {
        ch_pd.clear();
    }

    void print(char c)
    {
        uart.put(c);
    }

    void print(const char *data)
    {
        for (; *data; ++data) {
            uart.put(*data);
        }
    }

    bool await_response(const char *expected, unsigned int timeout)
    {
        eMote3_GPTM gptm = eMote3_GPTM{0, timeout};
        gptm.enable();
        unsigned int i = 0;
        while (gptm.running()) {
            if (uart.has_data()) {
                char c = uart.get();
                if (c == expected[i]) {
                    i += 1;
                    if (expected[i] == '\0') {
                        return true;
                    }
                } else {
                    i = (c == expected[0] ? 1 : 0);
                }
            }
        }
        return false;
    }

    void flush()
    {
        print(ESP_LINE_END);
        while (uart.has_data()) {
            uart.get();
        }
    }

    bool test_at()
    {
        flush();
        print("AT" ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

    bool software_restart()
    {
        flush();
        print("AT+RST" ESP_LINE_END);
        if (await_response(ESP_OK_RESPONSE, ESP_TIMEOUT)) {
            return await_response("ready", ESP_MAX_TIMEOUT);
        }
        return false;
    }

    bool hardware_restart()
    {
        reset.clear();
        eMote3_GPTM::delay(1000000);
        reset.set();
    }

    void disable_echo()
    {
        print("ATE0" ESP_LINE_END);
    }

    // 1 - station
    // 2 - access point
    // 3 - both
    bool set_mode(int mode)
    {
        flush();
        if (mode > 0 && mode < 4) {
            print("AT+CWMODE=");
            print(mode + '0');
            print(ESP_LINE_END);
            return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
        }
        return false;
    }

    bool get_mode(int *mode)
    {
        flush();
        print("AT+CWMODE?" ESP_LINE_END);
        if (await_response("+CWMODE:", ESP_TIMEOUT)) {
            *mode = uart.get() - '0';
            return true;
        }
        return false;
    }

    // tries to join n times
    bool join(const char *ssid, const char *pwd, int n)
    {
        for (unsigned int i = 0; i < n; ++i) {
            flush();
            print("AT+CWJAP=\"");
            print(ssid);
            print("\",\"");
            print(pwd);
            print('\"');
            print(ESP_LINE_END);
            if (await_response(ESP_OK_RESPONSE, ESP_MAX_TIMEOUT)) {
                return true;
            }
        }
        return false;
    }

    bool disconnect()
    {
        flush();
        print("AT+CWQAP" ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

    bool config(const char *ssid, const char *pwd, const char *ch, int ecn)
    {
        flush();
        print("AT+CWSAP=\"");
        print(ssid);
        print("\",\"");
        print(pwd);
        print("\",");
        print(ch);
        print(',');
        print(ecn + '0');
        print(ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

    bool set_auto_connect(bool auto_connect)
    {
        flush();
        if (auto_connect){
            print("AT+CWAUTOCONN=1" ESP_LINE_END);
        } else {
            print("AT+CWAUTOCONN=0" ESP_LINE_END);
        }
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

    bool get_auto_connect(bool *auto_connect)
    {
        flush();
        print("AT+CWAUTOCONN?" ESP_LINE_END);
        if (await_response("+CWAUTOCONN:", ESP_TIMEOUT)) {
            *auto_connect = uart.get() - '0';
            return true;
        }
        return false;
    }

    bool set_sta_mac(const char mac[12])
    {
        flush();
        print("AT+CIPSTAMAC=\"");
        for (unsigned int i = 0; i < 10; i += 2) {
            print(mac[i]);
            print(mac[i+1]);
            print(':');
        }
        print(mac[10]);
        print(mac[11]);
        print("\"" ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

    bool get_sta_mac(char mac[12])
    {
        flush();
        print("AT+CIPSTAMAC?" ESP_LINE_END);
        if (await_response("+CIPSTAMAC:\"", ESP_TIMEOUT)) {
            unsigned int i = 0;
            char c;
            while ((c = uart.get()) != '\r') {
                if (c != ':') {
                    mac[i] = c;
                    ++i;
                }
            }
            return true;
        }
        for (unsigned int i = 0; i < 12; ++i) {
            mac[i] = 'x';
        }
        return false;
    }

    bool set_ap_mac(const char mac[12])
    {
        flush();
        print("AT+CIPAPMAC=\"");
        for (unsigned int i = 0; i < 10; i += 2) {
            print(mac[i]);
            print(mac[i+1]);
            print(':');
        }
        print(mac[10]);
        print(mac[11]);
        print("\"" ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

    bool get_ap_mac(char mac[12])
    {
        flush();
        print("AT+CIPAPMAC?" ESP_LINE_END);
        if (await_response("+CIPAPMAC:\"", ESP_TIMEOUT)) {
            unsigned int i = 0;
            char c;
            while ((c = uart.get()) != '\r') {
                if (c != ':') {
                    mac[i] = c;
                    ++i;
                }
            }
            return true;
        }
        for (unsigned int i = 0; i < 12; ++i) {
            mac[i] = 'x';
        }
        return false;
    }

    bool set_ap_ip(const char *ip)
    {
        flush();
        print("AT+CIPSTA=\"");
        print(ip);
        print("\"" ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT); 
    }

    bool get_ap_ip(int ip[4])
    {
        flush();
        print("AT+CIPAP?" ESP_LINE_END);
        if (await_response("+CIPAP:\"", ESP_TIMEOUT)) {
            unsigned int i;
            for (i = 0; i < 4; ++i) {
                ip[i] = 0;
            }
            i = 0;
            char c;
            while ((c = uart.get()) != '\"') {
                if (c == '.') {
                    i++;
                } else {
                    ip[i] = ip[i] * 10 + c - '0';
                }
            }
            return true;
        }
        for (unsigned int i = 0; i < 4; ++i) {
            ip[i] = -1;
        }
        return false;
    }

    bool set_sta_ip(const char *ip)
    {
        flush();
        print("AT+CIPSTA=\"");
        print(ip);
        print("\"" ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT); 
    }

    bool get_sta_ip(int ip[4])
    {
        flush();
        print("AT+CIPSTA?" ESP_LINE_END);
        if (await_response("+CIPSTA:\"", ESP_TIMEOUT)) {
            unsigned int i;
            for (i = 0; i < 4; ++i) {
                ip[i] = 0;
            }
            i = 0;
            char c;
            while ((c = uart.get()) != '\"') {
                if (c == '.') {
                    i++;
                } else {
                    ip[i] = ip[i] * 10 + c - '0';
                }
            }
            return true;
        }
        for (unsigned int i = 0; i < 4; ++i) {
            ip[i] = -1;
        }
        return false;
    }

    bool connect_tcp(const char *url, const char *port)
    {
        flush();
        print("AT+CIPSTART=\"TCP\",\"");
        print(url);
        print("\",");
        print(port);
        print(ESP_LINE_END);
        return await_response("CONNECT", ESP_MAX_TIMEOUT);
    }

    bool get_status(int *status)
    {
        flush();
        print("AT+CIPSTATUS" ESP_LINE_END);
        if (await_response("+CIPSTATUS:", ESP_TIMEOUT)) {
            *status = uart.get() - '0';
            return true;
        }
        return false;
    }

    bool http_request(const char *url, const char *port, const char *request, const char *size)
    {
        flush();
        if (connect_tcp(url, port)) {
            return send_data(request, size);
        }
        return false;
    }

    bool send_data(const char *data)
    {
        flush();
        print("AT+CIPSEND" ESP_LINE_END);
        if (await_response(">", ESP_TIMEOUT)) {
            print(data);
            print("+++");
            return await_response(ESP_SEND_OK_RESPONSE, ESP_MAX_TIMEOUT);
        }
        return false;
    }

    bool send_data(const char *data, const char *size)
    {
        flush();
        print("AT+CIPSEND=");
        print(size);
        print(ESP_LINE_END);
        if (await_response(">", ESP_TIMEOUT)) {
            print(data);
            return await_response(ESP_SEND_OK_RESPONSE, ESP_MAX_TIMEOUT);
        }
        return false;
    }

    bool send_data(const char *data, const char *size, const char *ch)
    {
        flush();
        print("AT+CIPSEND=");
        print(ch);
        print(',');
        print(size);
        print(ESP_LINE_END);
        if (await_response(">", ESP_TIMEOUT)) {
            print(data);
            return await_response(ESP_SEND_OK_RESPONSE, ESP_MAX_TIMEOUT);
        }
        return false;
    }

    bool close_connection()
    {
        flush();
        print("AT+CIPCLOSE" ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

    bool close_connection(int channel)
    {
        flush();
        print("AT+CIPCLOSE=");
        print(channel + '0');
        print(ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

    bool set_multiple_connections(bool multiple_connections)
    {
        flush();
        if (multiple_connections){
            print("AT+CIPMUX=1" ESP_LINE_END);
        } else {
            print("AT+CIPMUX=0" ESP_LINE_END);
        }
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

    int get_multiple_connections(bool *multiple_connections) 
    {
        flush();
        print("AT+CIPMUX?" ESP_LINE_END);
        if (await_response("+CIPMUX:", ESP_TIMEOUT)) {
            *multiple_connections = uart.get() - '0';
            return true;
        }
        return false;
    }

    bool server(bool open, const char *port)
    {
        flush();
        if (open) {
            print("AT+CIPSERVER=1,");
        } else {
            print("AT+CIPSERVER=0,");
        }
        print(port);
        print(ESP_LINE_END);
        return await_response(ESP_OK_RESPONSE, ESP_TIMEOUT);
    }

private:
    GPIO &ch_pd;
    GPIO &reset;
    UART &uart;
};

#define SSID "LISHA"
#define PWD "password"

// GPRS functions mapped to ESP8266
// - send_command(const char *) does nothing
// - await_response(const char * unsigned int) aways returns true
// - set_baudrate() does nothing
// - sim_card_ready() and use_dns() connects the module to a network
// - set_http_url(const char *) and send_http_post(const char *, unsigned int size) does nothing and returns false
// - send_http_post(const char *, const char *, unsigned int) has a slightly different signature:
//   send_http_post(const char *, const char *, const char *, const char *, unsigned int)
class eMote3_WIFI : public eMote3_ESP8266 {
public:
    eMote3_WIFI(GPIO &pwrkey, GPIO &statusw, UART &uart):
        eMote3_ESP8266{pwrkey, statusw, uart}
    {}
    void on()
    {
        power_on();
        eMote3_GPTM::delay(3000000);
        turn_off_echo();
    }
    void off()
    {
        power_off();
    }
    void send_command(const char *command)
    {
    }
    bool await_response(const char *expected, unsigned int timeout)
    {
        return true;
    }
    void set_baudrate()
    {
    }
    void turn_off_echo()
    {
        disable_echo();
    }
    bool sim_card_ready()
    {
        if (set_mode(1)) {
            return join(SSID, PWD, 5);
        }
        return false;
    }
    bool use_dns()
    {
        return sim_card_ready();
    }
    bool open_tcp(const char *adress, const char *port)
    {
        return connect_tcp(adress, port);
    }
    bool send_tcp(const char *payload)
    {
        send_data(payload);
    }
    bool close_tcp()
    {
        close_connection();
    }
    bool set_http_url(const char *url)
    {
        return false;
    }
    bool send_http_post(const char *data, unsigned int size)
    {
        return false;
    }
    bool send_http_post(const char *url, const char *port, const char *page, const char *data, unsigned int data_size)
    {
        // calculate the message size
        int p = strlen(page);
        char buf[32] = "";
        int l = utoa(data_size, buf);
        buf[l] = '\0';
        int u = strlen(url);
        int size = p + l + u + data_size + 106;
        
        // format the message to be a request
        char data_with_header[size];
        strcpy(data_with_header, "POST ");
        strcat(data_with_header, page);
        strcat(data_with_header, " HTTP/1.1" ESP_LINE_END "Host: ");
        strcat(data_with_header, url);
        strcat(data_with_header, ESP_LINE_END "Accept: */*" ESP_LINE_END "Content-Type: application/x-www-form-urlencoded" ESP_LINE_END "Content-Length: ");
        strcat(data_with_header, buf);
        strcat(data_with_header, ESP_LINE_END ESP_LINE_END);
        strcat(data_with_header, data);
        strcat(data_with_header, ESP_LINE_END);

        // send it
        buf[utoa(size, buf)] = '\0';
        return http_request(url, port, data_with_header, buf);
    }
};

__END_SYS

#endif
