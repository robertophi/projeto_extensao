package com.segmentationfault.apps.testapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


public class MainActivity extends AppCompatActivity {
    private int counter = 0;
    private TextView counterText;
    RequestQueue mRequestQueue;
    public static final String TAG = "MyTag";
    String url ="http://192.168.4.1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button prevButton = (Button) findViewById(R.id.prev_button);
        Button nextButton = (Button) findViewById(R.id.next_button);

        counterText = (TextView) findViewById(R.id.counter);
        mRequestQueue = Volley.newRequestQueue(this);

        prevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url + "/?prev=1",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                counter--;
                                counterText.setText(Integer.toString(counter));
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Request Failed", Toast.LENGTH_SHORT).show();
                    }
                });
                // Add the request to the RequestQueue.
                mRequestQueue.add(stringRequest);
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url + "/?next=1",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                counter++;
                                counterText.setText(Integer.toString(counter));
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Request Failed", Toast.LENGTH_SHORT).show();
                    }
                });
                // Add the request to the RequestQueue.
                mRequestQueue.add(stringRequest);
            }
        });
    }

    @Override
    protected void onStop () {
        super.onStop();
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(TAG);
        }
    }
}
