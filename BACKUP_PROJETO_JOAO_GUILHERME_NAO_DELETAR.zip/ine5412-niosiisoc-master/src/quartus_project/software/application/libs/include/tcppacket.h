#ifndef TCPPACKET_H
#define TCPPACKET_H

class TCPPacket {
public:
	~TCPPacket();
	unsigned int getSoundData() { return 0; };

private:
	TCPPacket();
};

#endif
