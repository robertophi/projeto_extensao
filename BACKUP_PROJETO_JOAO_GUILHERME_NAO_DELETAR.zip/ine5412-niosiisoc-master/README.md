# Equipamento Vestível para Expansão da Percepção Humana

Links úteis: [Slack](https://segmentationfaultteam.slack.com/), [Wiki](https://github.com/joaogui/ine5412-niosiisoc/wiki), [Issues](https://github.com/joaogui/ine5412-niosiisoc/issues).

Este projeto propõe o desenvolvimento de um equipamento embarcado vestível que se comunique via rede wi-fi com um smartphone, de onde recebe streams de dados ou requisições HTTP de tipo POST e os codifica em estímulos vibro-táteis aplicados ao longo do corpo do usuário, através de um vestimenta que integra o equipamento.
Esse equipamento visa tanto a substituição sensorial para portadores de deficiências auditiva e visual, quanto a expansão sensorial para pessoa sem deficiência, pois permite que informações naturalmente imperceptíveis, como campo eletromagnético, aceleração, status de objetos inteligentes, entre outros, possam ser sentidos como estímulos vibro-táteis de modo natural e inconsciente pelo usuário.


### Regras de desenvolvimento

* Nomes de arquivos e diretórios sem espaços.
* Mantenha a descrição do commit na terceira pessoa do presente e em português. Ex.: Implementa funcionalidade X
* Referencie qual issue o commit resolve.
* Tente particionar o commit em maiores partes possíveis, ou seja evite commits com grande quantidade de códigos não relacionadas.
* O padrão de estilo de código a ser seguido pode ser achado [aqui](https://google.github.io/styleguide/cppguide.html)
* O idioma a ser utilizado no desenvolvimeto é o inglês.
