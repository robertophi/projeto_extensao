
#include "sys/alt_stdio.h"
#define matrixAddress 9038
#define fftAddress 9028

int main()
{
  alt_putstr("Hello from Nios II!\n");
  volatile unsigned int *data;
  unsigned int x;
  data = fftAddress;

  *data = 12345;
  usleep(300);
  x = *(data+4);
  alt_printf("%d",x);
  while (1);

  return 0;
}
